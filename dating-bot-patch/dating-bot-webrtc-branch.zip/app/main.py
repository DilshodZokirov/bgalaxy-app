from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from app.api.signaling import router as signaling_router
from app.api.webapp import router as webapp_api_router
from app.database import init_db

app = FastAPI(title="Dating Bot API")

app.include_router(webapp_api_router)
app.include_router(signaling_router)
app.mount("/webapp", StaticFiles(directory="app/webapp", html=True), name="webapp")


@app.on_event("startup")
async def on_startup():
    await init_db()


@app.get("/health")
async def health():
    return {"status": "ok"}
